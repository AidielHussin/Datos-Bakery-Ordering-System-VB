﻿Imports System.Data.OleDb

Public Class Login
    Dim connection As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb")

    Private Sub btnSignIn_Click(sender As Object, e As EventArgs) Handles btnSignIn.Click
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Check if the entered credentials are for admin
        If username = "admin" AndAlso password = "admin1234." Then
            ' If the credentials match, open the orderLogAdmin form
            Dim adminForm As New orderLogAdmin()
            adminForm.Show()
            Me.Hide()

       Else
            ' Create the select query
            Dim query As String = "SELECT * FROM tblCustomer WHERE custUsername = @Username AND custPassword = @Password"

            ' Create the command and add the parameters
            Dim command As OleDbCommand = New OleDbCommand(query, connection)
            command.Parameters.AddWithValue("@Username", username)
            command.Parameters.AddWithValue("@Password", password)

            Try
                ' Open the connection
                connection.Open()

                ' Execute the query and read the data
                Dim reader As OleDbDataReader = command.ExecuteReader()
                If reader.Read() Then
                    ' If credentials are correct, get the custID and open the next form
                    Dim custID As Integer = Convert.ToInt32(reader("custID"))
                    Dim Account As New Account(custID, username)
                    Account.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Invalid username or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                ' Close the reader and the connection
                reader.Close()
                connection.Close()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        ' Open the Register form
        Dim registerForm As New Register()
        registerForm.Show()
        Me.Hide()
    End Sub

End Class
