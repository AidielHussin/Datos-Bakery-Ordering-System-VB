﻿Imports System.Data.OleDb
Imports DatosBakeryOrderingSystem.datosBakeryDataSetTableAdapters

Public Class Users
    Private connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb"
    Private Sub Users_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load data into the DataGridView on form load
        LoadData()

        ' Add event handlers for selection change and double-click
        AddHandler DataGridView1.SelectionChanged, AddressOf DataGridView1_SelectionChanged
        AddHandler DataGridView1.CellDoubleClick, AddressOf DataGridView1_CellDoubleClick
    End Sub


    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If btnAdd.Text = "Add" Then
            btnAdd.Text = "Cancel"
            ClearInputFields()
        Else
            btnAdd.Text = "Add"
            ClearInputFields()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If btnUpdate.Text = "Update" Then
            btnUpdate.Text = "Cancel"

        Else
            btnUpdate.Text = "Update"
            ClearInputFields()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If btnAdd.Text = "Cancel" Then
            InsertRecord()
        ElseIf btnUpdate.Text = "Cancel" Then
            UpdateRecord()
        End If
        btnAdd.Text = "Add"
        btnUpdate.Text = "Update"
        LoadData()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show(Me, "Do you want to DELETE?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
            DeleteRecord()
            LoadData()
        End If
    End Sub

    Private Sub ClearInputFields()
        lblCustID.Text = "" ' Use the Text property of the Label control
        txtUsername.Text = ""
        txtEmail.Text = ""
        txtPassword.Text = ""
        txtFullName.Text = ""
        comboState.Text = ""
        txtPostcode.Text = ""
        txtAddress.Text = ""
        txtNoPhone.Text = ""
    End Sub

    'Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs)
    '    LoadSelectedRecord()
    'End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs)
        If btnUpdate.Text <> "Cancel" Then
            LoadSelectedRecord()
        End If
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs)

        Dim selectedID = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn1").Value.ToString()
        Dim selectedUsername = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn8").Value.ToString()
        Dim selectedEmail = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn7").Value.ToString()
        Dim selectedPhone = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn3").Value.ToString()

        MessageBox.Show($"Selected User ID: {selectedID}, Username: {selectedUsername}, Email: {selectedEmail}, Phone : {selectedPhone}")
    End Sub

    Private Sub LoadSelectedRecord()
        If DataGridView1.CurrentRow IsNot Nothing Then
            Try
                lblCustID.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn1").Value.ToString()
                txtUsername.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn8").Value.ToString()
                txtEmail.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn7").Value.ToString()
                txtPassword.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn9").Value.ToString()
                txtFullName.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn2").Value.ToString()
                comboState.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn6").Value.ToString()
                txtPostcode.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn5").Value.ToString()
                txtAddress.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn4").Value.ToString()
                txtNoPhone.Text = DataGridView1.CurrentRow.Cells("DataGridViewTextBoxColumn3").Value.ToString()
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        Else
            MessageBox.Show("No row is selected. Please select a row first.")
        End If
    End Sub


    Private Sub InsertRecord()
        ' Trim input fields
        txtUsername.Text = txtUsername.Text.Trim()
        txtEmail.Text = txtEmail.Text.Trim()
        txtPassword.Text = txtPassword.Text.Trim()
        txtFullName.Text = txtFullName.Text.Trim()
        comboState.Text = comboState.Text.Trim()
        txtPostcode.Text = txtPostcode.Text.Trim()
        txtAddress.Text = txtAddress.Text.Trim()
        txtNoPhone.Text = txtNoPhone.Text.Trim()


        If Not ValidateFields() Then Exit Sub

        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("INSERT INTO tblCustomer (custUsername, custEmail, custPassword, custName, custState, custPostcode, custAddress, custPhone) VALUES (@custUsername, @custEmail, @custPassword, @custName, @custState, @custPostcode, @custAddress, @custPhone)", conn)
            cmd.Parameters.AddWithValue("@custUsername", txtUsername.Text)
            cmd.Parameters.AddWithValue("@custEmail", txtEmail.Text)
            cmd.Parameters.AddWithValue("@custPassword", txtPassword.Text)
            cmd.Parameters.AddWithValue("@custName", txtFullName.Text)
            cmd.Parameters.AddWithValue("@custState", comboState.Text)
            cmd.Parameters.AddWithValue("@custPostcode", txtPostcode.Text)
            cmd.Parameters.AddWithValue("@custAddress", txtAddress.Text)
            cmd.Parameters.AddWithValue("@custPhone", txtNoPhone.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Private Function ValidateFields() As Boolean
        If txtUsername.Text.Length > 50 Then
            MessageBox.Show("Username is too long. Maximum 50 characters.")
            Return False
        End If
        If txtEmail.Text.Length > 100 Then
            MessageBox.Show("Email is too long. Maximum 100 characters.")
            Return False
        End If
        If txtPassword.Text.Length > 50 Then
            MessageBox.Show("Password is too long. Maximum 50 characters.")
            Return False
        End If
        If txtFullName.Text.Length > 100 Then
            MessageBox.Show("Full Name is too long. Maximum 100 characters.")
            Return False
        End If
        If comboState.Text.Length > 50 Then
            MessageBox.Show("State is too long. Maximum 50 characters.")
            Return False
        End If
        If txtPostcode.Text.Length > 10 Then
            MessageBox.Show("Postcode is too long. Maximum 10 characters.")
            Return False
        End If
        If txtAddress.Text.Length > 255 Then
            MessageBox.Show("Address is too long. Maximum 255 characters.")
            Return False
        End If
        If txtNoPhone.Text.Length > 20 Then
            MessageBox.Show("Phone number is too long. Maximum 20 characters.")
            Return False
        End If

        Return True
    End Function



    Private Sub UpdateRecord()
        ' Trim input fields
        txtUsername.Text = txtUsername.Text.Trim()
        txtEmail.Text = txtEmail.Text.Trim()
        txtPassword.Text = txtPassword.Text.Trim()
        txtFullName.Text = txtFullName.Text.Trim()
        comboState.Text = comboState.Text.Trim()
        txtPostcode.Text = txtPostcode.Text.Trim()
        txtAddress.Text = txtAddress.Text.Trim()
        txtNoPhone.Text = txtNoPhone.Text.Trim()

        If Not ValidateFields() Then Exit Sub

        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("UPDATE tblCustomer SET custUsername = @custUsername, custEmail = @custEmail, custPassword = @custPassword, custName = @custName, custState = @custState, custPostcode = @custPostcode, custAddress = @custAddress, custPhone = @custPhone WHERE custID = @custID", conn)
            cmd.Parameters.AddWithValue("@custUsername", txtUsername.Text)
            cmd.Parameters.AddWithValue("@custEmail", txtEmail.Text)
            cmd.Parameters.AddWithValue("@custPassword", txtPassword.Text)
            cmd.Parameters.AddWithValue("@custName", txtFullName.Text)
            cmd.Parameters.AddWithValue("@custState", comboState.Text)
            cmd.Parameters.AddWithValue("@custPostcode", txtPostcode.Text)
            cmd.Parameters.AddWithValue("@custAddress", txtAddress.Text)
            cmd.Parameters.AddWithValue("@custPhone", txtNoPhone.Text)
            cmd.Parameters.AddWithValue("@custID", lblCustID.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    'Private Sub DeleteRecord()
    '    Using conn As New OleDbConnection(connectionString)
    '        Dim cmd As New OleDbCommand("DELETE FROM tblCustomer WHERE custID = @custID", conn)
    '        cmd.Parameters.AddWithValue("@custID", lblCustID.Text)
    '        conn.Open()
    '        cmd.ExecuteNonQuery()
    '    End Using

    'End Sub

    Private Sub DeleteRecord()
        If String.IsNullOrEmpty(lblCustID.Text) Then
            MessageBox.Show("No customer selected. Please select a customer to delete.")
            Exit Sub
        End If

        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("DELETE FROM tblCustomer WHERE custID = @custID", conn)
            cmd.Parameters.AddWithValue("@custID", lblCustID.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub LoadData()
        ' Load your data from the database and display it
        Dim dt As New DataTable()
        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("SELECT * FROM tblCustomer", conn)
            conn.Open()
            Using reader As OleDbDataReader = cmd.ExecuteReader()
                dt.Load(reader)
            End Using
        End Using
        'DataGridView1.DataSource = dt
        TblCustomerBindingSource1.DataSource = dt
        DataGridView1.DataSource = TblCustomerBindingSource1
    End Sub

    'Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
    '    If btnAdd.Text = "Add" Then
    '        btnAdd.Text = "Cancel"
    '        TblCustomerBindingSource1.AddNew()
    '    Else
    '        btnAdd.Text = "Add"
    '        TblCustomerBindingSource1.CancelEdit()
    '        TblCustomerTableAdapter1.Update(DatosBakeryDataSet2.tblCustomer)
    '    End If
    'End Sub

    'Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
    '    If btnUpdate.Text = "Update" Then
    '        btnUpdate.Text = "Cancel"
    '    Else
    '        btnUpdate.Text = "Update"
    '        TblCustomerBindingSource1.CancelEdit()
    '        TblCustomerTableAdapter1.Update(DatosBakeryDataSet2.tblCustomer)
    '    End If

    'End Sub

    'Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
    '    btnAdd.Text = "Add"
    '    btnUpdate.Text = "Update"
    '    TblCustomerBindingSource1.EndEdit()
    '    TblCustomerTableAdapter1.Update(DatosBakeryDataSet2.tblCustomer)
    'End Sub

    'Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
    '    If MessageBox.Show(Me, " Do you want to DELETE?", "Confirmation",
    '        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
    '        TblCustomerBindingSource1.RemoveCurrent()
    '        TblCustomerTableAdapter1.Update(DatosBakeryDataSet2.tblCustomer)
    '    End If
    'End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearInputFields()
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        TblCustomerBindingSource1.MoveFirst()
    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        TblCustomerBindingSource1.MoveLast()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        TblCustomerBindingSource1.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        TblCustomerBindingSource1.MoveNext()
    End Sub

    Private Sub OrderLogToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderLogToolStripMenuItem.Click
        orderLogAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        ProductAdmin.Show()
        Me.Hide()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Me.Close()
        login.Show()
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        PrintDialog1.Document = PrintDocument1
        If PrintDialog1.ShowDialog() = DialogResult.OK Then
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()
        End If

    End Sub

    Private Sub printDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim title As String = "Users"
        Dim titleFont As New Font("Arial", 14, FontStyle.Bold)
        Dim titleHeight As Integer = e.Graphics.MeasureString(title, titleFont).Height

        ' Draw the title
        e.Graphics.DrawString(title, titleFont, Brushes.Black, New PointF(0, 0))

        ' Create a bitmap of the DataGridView
        Dim bm As New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
        DataGridView1.DrawToBitmap(bm, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))

        ' Adjust the position where the DataGridView is drawn to be below the title
        Dim dataGridViewPosition As New Point(0, titleHeight + 10) ' 10 pixels below the title
        e.Graphics.DrawImage(bm, dataGridViewPosition)
    End Sub
End Class