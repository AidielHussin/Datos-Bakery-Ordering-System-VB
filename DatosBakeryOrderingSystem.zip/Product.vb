﻿Public Class Product

End Class