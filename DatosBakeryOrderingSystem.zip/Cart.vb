﻿Imports System.Data.OleDb

Public Class Cart
    Private custID As Integer
    Dim username As String
    Dim connection As New OleDbConnection
    Dim adapter As New OleDbDataAdapter
    Dim ds As New DataSet
    Dim selectedProductPrice As Double = 0.0

    Public Sub New(ByVal custID As Integer, ByVal Username As String)
        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        InitializeDataGridView()

        ' Set the custID
        Me.custID = custID
        Me.username = Username
    End Sub

    Private Sub Cart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set up your connection string
        connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb"
    End Sub

    Private Sub InitializeDataGridView()
        DataGridView1.Columns.Clear()
        DataGridView1.Columns.Add("ProductID", "Product ID")
        DataGridView1.Columns.Add("ProductName", "Product Name")
        DataGridView1.Columns.Add("ProductPrice", "Product Price")
    End Sub

    Public Sub AddToCart(productID As String, productName As String, productPrice As Decimal)
        ' Add the product to the DataGridView
        DataGridView1.Rows.Add(productID, productName, productPrice)
    End Sub
    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        If DataGridView1.Rows.Count > 0 Then
            Dim paymentMethod As String = If(RadioCash.Checked, "Cash", "Transfer")
            Dim services As String = If(radioDelivery.Checked, "Delivery", "Pickup")

            ' Calculate total price
            Dim totalPrice As Double = CalculateTotalPrice()

            For Each row As DataGridViewRow In DataGridView1.Rows
                If Not row.IsNewRow Then
                    Dim productId As String = row.Cells("ProductID").Value.ToString()
                    'Dim amount As Double = Convert.ToDouble(row.Cells("ProductPrice").Value)'
                    Dim amount As Double = totalPrice

                    Try
                        ' Insert into database

                        InsertOrder(custID, productId, paymentMethod, services, amount)
                    Catch ex As Exception
                        MessageBox.Show("Error confirming order: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return
                    End Try
                End If
            Next

            ' Show receipt form with order details- Convert.ToDouble(DataGridView1.Rows(0).Cells("ProductPrice").Value)
            Dim receiptForm As New Receipt()
            receiptForm.SetReceiptData(custID, DataGridView1.Rows(0).Cells("ProductID").Value.ToString(), paymentMethod, services, totalPrice)
            receiptForm.ShowDialog()
        Else
            MessageBox.Show("No products in the cart to confirm.")
        End If
    End Sub

    Private Function CalculateTotalPrice() As Double
        Dim totalPrice As Double = 0.0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                totalPrice += Convert.ToDouble(row.Cells("ProductPrice").Value)
            End If
        Next

        If radioDelivery.Checked Then
            totalPrice += 4.0
        End If

        Return totalPrice
    End Function

    Private Sub InsertOrder(customerId As Integer, productId As String, paymentMethod As String, services As String, amount As Double)
        Try
            ' Prepare the INSERT command
            Dim query As String = "INSERT INTO tblOrder (custID, productID, payment, service, amount) " &
                                  "VALUES (@custID, @productID, @payment, @service, @amount)"

            ' Create and open connection
            Using cmd As New OleDbCommand(query, connection)
                cmd.Parameters.AddWithValue("@custID", customerId)
                cmd.Parameters.AddWithValue("@productID", productId)
                cmd.Parameters.AddWithValue("@payment", paymentMethod)
                cmd.Parameters.AddWithValue("@service", services)
                cmd.Parameters.AddWithValue("@amount", amount)

                connection.Open()
                cmd.ExecuteNonQuery()
            End Using
        Catch ex As Exception
            Throw New Exception("Error inserting order: " & ex.Message)
        Finally
            connection.Close()
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        ' Get the product ID from the text box
        Dim productIdToDelete As String = txtProductID.Text

        ' Search for the row with the specified product ID and remove it
        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow AndAlso row.Cells("ProductID").Value.ToString() = productIdToDelete Then
                DataGridView1.Rows.Remove(row)
                Exit For
            End If
        Next
    End Sub

    Private Sub btnTotalPrice_Click(sender As Object, e As EventArgs) Handles btnTotalPrice.Click
        Dim totalPrice As Double = CalculateTotalPrice()
        MessageBox.Show("Total price: RM " & totalPrice.ToString("F2"), "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub


    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        ' Open the Product form
        Dim productListForm As New ProductList(custID, username)
        productListForm.Show()
        Me.Hide()
    End Sub


    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub AccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountToolStripMenuItem.Click
        Dim accountForm As New Account(custID, username)
        accountForm.Show()
        Me.Hide()
    End Sub
End Class
