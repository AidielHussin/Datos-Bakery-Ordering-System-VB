﻿Public Class Receipt
    Public Sub SetReceiptData(customerId As Integer, productId As String, paymentMethod As String, services As String, amount As Double)
        ' Clear listbox and display receipt details
        lstReceipt.Items.Clear()
        lstReceipt.Items.Add("               RECEIPT                ")
        lstReceipt.Items.Add("-----------------------------------------")

        ' Add receipt details with formatting
        lstReceipt.Items.Add($"Customer ID        : {customerId}")
        lstReceipt.Items.Add($"Product ID           : {productId}")
        lstReceipt.Items.Add($"Payment Method : {paymentMethod}")
        lstReceipt.Items.Add($"Services             : {services}")
        lstReceipt.Items.Add($"Amount              : RM {amount:F2}")

        ' Add a footer
        lstReceipt.Items.Add("-----------------------------------------")
        lstReceipt.Items.Add("Thank you for your purchase!")
        lstReceipt.Items.Add("-----------------------------------------")
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Me.Close() ' Close the receipt form
    End Sub

End Class
