﻿Imports System.Data.OleDb

Public Class Account
    Dim connection As New OleDbConnection
    Dim command As OleDbCommand
    Dim sql As String = Nothing
    Dim custID As Integer
    Dim username As String

    Public Sub New(ByVal custID As Integer, ByVal Username As String)
        ' This call is required by the designer.
        InitializeComponent()

        ' Set the username
        Me.custID = custID
        Me.username = Username
        ' Set the connection string
        connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb"

        ' Load the data into the form
        LoadData()
    End Sub

    Private Sub LoadData()
        ' Create the select query
        Dim query As String = "SELECT * FROM tblCustomer WHERE custUsername = @Username"

        ' Create the command and add the parameter
        Dim command As OleDbCommand = New OleDbCommand(query, connection)
        command.Parameters.AddWithValue("@Username", username)

        Try
            ' Open the connection
            connection.Open()

            ' Create an OleDbDataReader to read the data
            Dim reader As OleDbDataReader = command.ExecuteReader()

            ' If there is a row returned, load the data into the form
            If reader.Read() Then
                lblFullName.Text = reader("custName").ToString()
                lblEmail.Text = reader("custEmail").ToString()
                lblUsername.Text = reader("custUsername").ToString()
                lblPhoneNumber.Text = reader("custPhone").ToString()
                lblAddress.Text = reader("custAddress").ToString()
                lblPostcode.Text = reader("custPostcode").ToString()
                lblState.Text = reader("custState").ToString()

            End If

            ' Close the reader and the connection
            reader.Close()
            connection.Close()
        Catch ex As Exception
            ' Show error message
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Get the updated details from the textboxes
        Dim phoneNumber As String = txtPhoneNumber.Text
        Dim address As String = txtAddress.Text
        Dim postcode As String = txtPostCode.Text
        Dim state As String = String.Empty

        ' Check if cmbState has a selected item
        If cmbState.SelectedItem IsNot Nothing Then
            state = cmbState.SelectedItem.ToString()
        End If

        ' Check if any field is empty
        If String.IsNullOrWhiteSpace(phoneNumber) OrElse
       String.IsNullOrWhiteSpace(address) OrElse
       String.IsNullOrWhiteSpace(postcode) OrElse
       String.IsNullOrWhiteSpace(state) Then
            MessageBox.Show("Please fill all the fields.", "Incomplete Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Create the update query
        Dim query As String = "UPDATE tblCustomer SET custPhone = @PhoneNumber, custAddress = @Address, custPostcode = @Postcode, custState = @State WHERE custUsername = @Username"

        ' Create the command and add the parameters
        Dim command As OleDbCommand = New OleDbCommand(query, connection)
        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber)
        command.Parameters.AddWithValue("@Address", address)
        command.Parameters.AddWithValue("@Postcode", postcode)
        command.Parameters.AddWithValue("@State", state)
        command.Parameters.AddWithValue("@Username", username)

        Try
            ' Open the connection
            connection.Open()

            ' Execute the query
            command.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("Update successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Update the labels with the new values
            lblPhoneNumber.Text = phoneNumber
            lblAddress.Text = address
            lblPostcode.Text = postcode
            lblState.Text = state
        Catch ex As Exception
            ' Show error message
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        Dim productListForm As New ProductList(custID, username)
        productListForm.Show()
        Me.Hide()
    End Sub


    Private Sub CartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CartToolStripMenuItem.Click
        Dim cartForm As New Cart(custID, username)
        cartForm.Show()
        Me.Hide()
    End Sub

End Class
