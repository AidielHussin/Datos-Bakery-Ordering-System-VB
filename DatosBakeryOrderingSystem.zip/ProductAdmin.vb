﻿Imports System.Drawing.Printing
Imports DatosBakeryOrderingSystem.datosBakeryDataSetTableAdapters
Imports System.Data.OleDb

Public Class ProductAdmin
    Private connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb"

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        PrintDialog1.Document = PrintDocument1
        If PrintDialog1.ShowDialog() = DialogResult.OK Then
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()
        End If
    End Sub

    Private Sub printDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim title As String = "Products"
        Dim titleFont As New Font("Arial", 14, FontStyle.Bold)
        Dim titleHeight As Integer = e.Graphics.MeasureString(title, titleFont).Height

        ' Draw the title
        e.Graphics.DrawString(title, titleFont, Brushes.Black, New PointF(0, 0))

        ' Create a bitmap of the DataGridView
        Dim bm As New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
        DataGridView1.DrawToBitmap(bm, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))

        ' Adjust the position where the DataGridView is drawn to be below the title
        Dim dataGridViewPosition As New Point(0, titleHeight + 10) ' 10 pixels below the title
        e.Graphics.DrawImage(bm, dataGridViewPosition)
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If btnAdd.Text = "Add" Then
            btnAdd.Text = "Cancel"
            ClearInputFields()
        Else
            btnAdd.Text = "Add"
            ClearInputFields()
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If btnUpdate.Text = "Update" Then
            btnUpdate.Text = "Cancel"
            LoadSelectedRecord()
        Else
            btnUpdate.Text = "Update"
            ClearInputFields()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If btnAdd.Text = "Cancel" Then
            InsertRecord()
        ElseIf btnUpdate.Text = "Cancel" Then
            UpdateRecord()
        End If
        btnAdd.Text = "Add"
        btnUpdate.Text = "Update"
        LoadData()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If MessageBox.Show(Me, "Do you want to DELETE?", "Confirmation",
                           MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = DialogResult.Yes Then
            DeleteRecord()
            LoadData()
        End If
    End Sub

    Private Sub ClearInputFields()
        ' Clear your input fields here
        txtProductID.Text = ""
        txtProductName.Text = ""
        txtPrice.Text = ""
    End Sub

    Private Sub LoadSelectedRecord()
        If DataGridView1.CurrentRow IsNot Nothing Then
            Try
                ' Debugging output
                Dim selectedProductID = DataGridView1.CurrentRow.Cells("ProductIDDataGridViewTextBoxColumn").Value.ToString()
                Dim selectedProductName = DataGridView1.CurrentRow.Cells("ProductNameDataGridViewTextBoxColumn").Value.ToString()
                Dim selectedPrice = DataGridView1.CurrentRow.Cells("ProductPriceDataGridViewTextBoxColumn").Value.ToString()


                ' Update the text fields
                txtProductID.Text = selectedProductID
                txtProductName.Text = selectedProductName
                txtPrice.Text = selectedPrice
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        Else
            MessageBox.Show("No row is selected. Please select a row first.")
        End If
    End Sub

    Private Sub InsertRecord()
        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("INSERT INTO tblProduct (productID, productName, productPrice) VALUES (@productID, @productName, @productPrice)", conn)
            cmd.Parameters.AddWithValue("@productID", txtProductID.Text)
            cmd.Parameters.AddWithValue("@productName", txtProductName.Text)
            cmd.Parameters.AddWithValue("@productPrice", txtPrice.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub UpdateRecord()
        'Using conn As New OleDbConnection(connectionString)
        '    Dim cmd As New OleDbCommand("UPDATE tblProduct SET productName = @productName, productPrice = @productPrice WHERE productID = @productID", conn)
        '    cmd.Parameters.AddWithValue("@productID", txtProductID.Text)
        '    cmd.Parameters.AddWithValue("@productName", txtProductName.Text)
        '    cmd.Parameters.AddWithValue("@productPrice", txtPrice.Text)
        '    conn.Open()
        '    cmd.ExecuteNonQuery()
        'End Using
        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("UPDATE tblProduct SET productName = @productName, productPrice = @productPrice WHERE productID = @productID", conn)
            cmd.Parameters.AddWithValue("@productName", txtProductName.Text)
            cmd.Parameters.AddWithValue("@productPrice", txtPrice.Text)
            cmd.Parameters.AddWithValue("@productID", txtProductID.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub DeleteRecord()
        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("DELETE FROM tblProduct WHERE productID = @productID", conn)
            cmd.Parameters.AddWithValue("@productID", txtProductID.Text)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Private Sub LoadData()
        ' Load your data from the database and display it
        Dim dt As New DataTable()
        Using conn As New OleDbConnection(connectionString)
            Dim cmd As New OleDbCommand("SELECT * FROM tblProduct", conn)
            conn.Open()
            Using reader As OleDbDataReader = cmd.ExecuteReader()
                dt.Load(reader)
            End Using
        End Using
        'DataGridView1.DataSource = dt
        TblProductBindingSource.DataSource = dt
        DataGridView1.DataSource = TblProductBindingSource
    End Sub


    'Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
    '    If MessageBox.Show(Me, "Are you sure, you want to DELETE?", "Delete",
    '                       MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
    '        TblProductBindingSource.RemoveCurrent()
    '        TblProductTableAdapter1.Update(DatosBakeryDataSet1.tblProduct)
    '    End If
    'End Sub

    'Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
    '    btnAdd.Text = "Add"
    '    btnUpdate.Text = "Update"
    '    TblProductBindingSource.EndEdit()
    '    TblProductTableAdapter1.Update(DatosBakeryDataSet1.tblProduct)
    '    MessageBox.Show(Me, "Data has been updated", "Update", MessageBoxButtons.OK, MessageBoxIcon.None)

    'End Sub

    'Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
    '    If btnUpdate.Text = "Update" Then
    '        btnUpdate.Text = "Cancel"

    '    Else
    '        btnUpdate.Text = "Update"
    '        TblProductBindingSource.CancelEdit()
    '        TblProductTableAdapter1.Update(DatosBakeryDataSet1.tblProduct)
    '    End If
    'End Sub

    'Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
    '    If btnAdd.Text = "Add" Then
    '        btnAdd.Text = "Cancel"
    '        TblProductBindingSource.AddNew()
    '    Else
    '        btnAdd.Text = "Add"
    '        TblProductBindingSource.CancelEdit()
    '        TblProductTableAdapter1.Update(DatosBakeryDataSet1.tblProduct)
    '    End If
    'End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        TblProductBindingSource.MoveFirst()
    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        TblProductBindingSource.MoveLast()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        TblProductBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        TblProductBindingSource.MoveNext()
    End Sub

    Private Sub DataGridView1_SelectionChanged(sender As Object, e As EventArgs)
        LoadSelectedRecord()
    End Sub

    Private Sub ProductAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DatosBakeryDataSet1.tblProduct' table. You can move, or remove it, as needed.
        Me.TblProductTableAdapter1.Fill(Me.DatosBakeryDataSet1.tblProduct)
        PrintPreviewDialog1.Document = PrintDocument1
        AddHandler DataGridView1.SelectionChanged, AddressOf DataGridView1_SelectionChanged
        ' In your form's constructor or Load event
        AddHandler DataGridView1.CellDoubleClick, AddressOf DataGridView1_CellDoubleClick

    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs)
        ' Debugging output
        Dim selectedProductID = DataGridView1.CurrentRow.Cells("ProductIDDataGridViewTextBoxColumn").Value.ToString()
        Dim selectedProductName = DataGridView1.CurrentRow.Cells("ProductNameDataGridViewTextBoxColumn").Value.ToString()
        Dim selectedPrice = DataGridView1.CurrentRow.Cells("ProductPriceDataGridViewTextBoxColumn").Value.ToString()

        ' Displaying values for debugging
        MessageBox.Show($"Selected Product ID: {selectedProductID}, Product Name: {selectedProductName}, Price: {selectedPrice}")
    End Sub

    Private Sub OrderLogToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderLogToolStripMenuItem.Click
        orderLogAdmin.Show()
        Me.Hide()
    End Sub


    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Me.Close()
        Login.Show()
    End Sub

    Private Sub UsersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UsersToolStripMenuItem.Click
        Me.Hide()
        Users.Show()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearInputFields()
    End Sub
End Class