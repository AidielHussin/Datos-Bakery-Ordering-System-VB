﻿Public Class ProductList
    Private custID As Integer
    Private selectedProductID As String
    Private selectedProductName As String
    Private selectedProductPrice As Decimal
    Private cartPage As Cart = Nothing
    Dim username As String

    Public Sub New(ByVal custID As Integer, ByVal Username As String)
        ' This call is required by the designer.
        InitializeComponent()
        ' Set the custID
        Me.custID = custID
        Me.username = Username
    End Sub

    Private Sub rdnJMC_CheckedChanged(sender As Object, e As EventArgs) Handles rdnJMC.CheckedChanged
        If rdnJMC.Checked Then
            selectedProductID = "001"
            selectedProductName = "Japanese Matcha Cake"
            selectedProductPrice = 79.9D
        End If
    End Sub

    Private Sub rdnCWC_CheckedChanged(sender As Object, e As EventArgs) Handles rdnCWC.CheckedChanged
        If rdnCWC.Checked Then
            selectedProductID = "002"
            selectedProductName = "Confenti Wanilla Cake"
            selectedProductPrice = 84.9D
        End If
    End Sub

    Private Sub rdnFBC_CheckedChanged(sender As Object, e As EventArgs) Handles rdnFBC.CheckedChanged
        If rdnFBC.Checked Then
            selectedProductID = "003"
            selectedProductName = "Fruity Bites Cake"
            selectedProductPrice = 78.5D
        End If
    End Sub

    Private Sub rdnNC_CheckedChanged(sender As Object, e As EventArgs) Handles rdnNC.CheckedChanged
        If rdnNC.Checked Then
            selectedProductID = "004"
            selectedProductName = "Nightsky Cake"
            selectedProductPrice = 55.5D
        End If
    End Sub

    Private Sub rdnCreampuff_CheckedChanged(sender As Object, e As EventArgs) Handles rdnCreampuff.CheckedChanged
        If rdnCreampuff.Checked Then
            selectedProductID = "005"
            selectedProductName = "Creampuff"
            selectedProductPrice = 5.9D
        End If
    End Sub

    Private Sub rdnWaffle_CheckedChanged(sender As Object, e As EventArgs) Handles rdnWaffle.CheckedChanged
        If rdnWaffle.Checked Then
            selectedProductID = "006"
            selectedProductName = "Waffle"
            selectedProductPrice = 4.5D
        End If
    End Sub

    Private Sub rdnRaspberryPie_CheckedChanged(sender As Object, e As EventArgs) Handles rdnRaspberryPie.CheckedChanged
        If rdnRaspberryPie.Checked Then
            selectedProductID = "007"
            selectedProductName = "Raspberry Pie"
            selectedProductPrice = 8.9D
        End If
    End Sub

    Private Sub rdnMilkDonut_CheckedChanged(sender As Object, e As EventArgs) Handles rdnMilkDonut.CheckedChanged
        If rdnMilkDonut.Checked Then
            selectedProductID = "008"
            selectedProductName = "Milk Donut"
            selectedProductPrice = 4.9D
        End If
    End Sub

    Private Sub btnCart_Click(sender As Object, e As EventArgs) Handles btnCart.Click
        If cartPage Is Nothing Then
            cartPage = New Cart(custID, username)
        End If

        cartPage.AddToCart(selectedProductID, selectedProductName, selectedProductPrice)
        cartPage.Show()
        Me.Hide()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Me.Close()
        Login.Show()
    End Sub


    Private Sub CartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CartToolStripMenuItem.Click
        Dim cartForm As New Cart(custID, username)
        cartForm.Show()
        Me.Hide()
    End Sub

    Private Sub AccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountToolStripMenuItem.Click
        Dim accountForm As New Account(custID, username)
        accountForm.Show()
        Me.Hide()
    End Sub


End Class
