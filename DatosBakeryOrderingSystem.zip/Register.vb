﻿Imports System.Data.OleDb

Public Class Register
    Dim connection As New OleDbConnection
    Dim command As OleDbCommand
    Dim sql As String = Nothing

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        connection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\uni\mac24 - ogos 24\csc301\VB Project\NEW CSC301\datosBakery.accdb"
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        ' Get the user input
        Dim fullName As String = txtFullName.Text
        Dim email As String = txtEmail.Text
        Dim username As String = txtUsername.Text
        Dim password As String = txtPassword.Text

        ' Validate the input
        If String.IsNullOrWhiteSpace(fullName) OrElse String.IsNullOrWhiteSpace(email) OrElse String.IsNullOrWhiteSpace(username) OrElse String.IsNullOrWhiteSpace(password) Then
            MessageBox.Show("Please fill all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Create the insert query
        Dim query As String = "INSERT INTO tblCustomer (custName, custEmail, custUsername, custPassword) VALUES (@FullName, @Email, @Username, @Password)"

        ' Create the command and add the parameters
        Dim command As OleDbCommand = New OleDbCommand(query, connection)
        command.Parameters.AddWithValue("@FullName", fullName)
        command.Parameters.AddWithValue("@Email", email)
        command.Parameters.AddWithValue("@Username", username)
        command.Parameters.AddWithValue("@Password", password)

        Try
            ' Open the connection
            connection.Open()

            ' Execute the query
            command.ExecuteNonQuery()

            ' Show success message
            MessageBox.Show("Registration successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Clear the textboxes
            txtFullName.Clear()
            txtEmail.Clear()
            txtUsername.Clear()
            txtPassword.Clear()

            Login.Show()
            Me.Hide()
        Catch ex As Exception
            ' Show error message
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ' Close the connection
            connection.Close()
        End Try
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Login.Show()
        Me.Hide()

    End Sub


End Class
